import React, { useState, useMemo } from 'react';
import { Package, Plus, Search, AlertTriangle, ArrowUpDown, Tag, Percent, Layers, Eye, Pencil, Trash2, ArrowUpAZ, ArrowDownZA, ArrowDown10, ArrowUp10, Filter, FileText, Download, Printer } from 'lucide-react';
import type { Product, Invoice } from '../types';
import { db } from '../db/indexedDB';
import { syncService } from '../services/syncService';
import { useLiveQuery } from 'dexie-react-hooks';
import { ProductDetailModal } from './ProductDetailModal';
import { ProductFormModal } from './ProductFormModal';
import { InventoryTurnoverChart } from './InventoryTurnoverChart';
import { CatalogExportModal } from './CatalogExportModal';
import { generateProductCatalogPDF } from '../services/pdfService';

interface InventoryViewProps {
  onOpenNewProduct: () => void;
  onOpenStockAdjust: (product: Product) => void;
  searchTerm: string;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  onOpenNewProduct,
  onOpenStockAdjust,
  searchTerm,
}) => {
  const [typeFilter, setTypeFilter] = useState<'all' | 'product' | 'service'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'description' | 'category' | 'price'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [selectedDetailProduct, setSelectedDetailProduct] = useState<Product | null>(null);
  const [selectedEditProduct, setSelectedEditProduct] = useState<Product | null>(null);
  const [isCatalogModalOpen, setIsCatalogModalOpen] = useState<boolean>(false);

  const products = useLiveQuery(() => db.products.toArray(), []) || [];
  const invoices = useLiveQuery(() => db.invoices.toArray(), []) || [];
  const companyProfile = useLiveQuery(() => db.companyProfile.get('default'), []);

  const handleDeleteProduct = async (product: Product) => {
    if (confirm(`¿Estás seguro de eliminar el artículo "${product.name}" (${product.sku}) del inventario?`)) {
      await db.products.delete(product.id);
      await syncService.queueChange('products', 'delete', { id: product.id });
    }
  };

  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      if (p.category && p.category.trim()) {
        set.add(p.category.trim());
      }
    });
    return Array.from(set).sort();
  }, [products]);

  const sortedAndFilteredProducts = useMemo(() => {
    const list = products.filter((p) => {
      const matchesSearch = 
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (p.description && p.description.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesType = typeFilter === 'all' || p.type === typeFilter;
      const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;

      return matchesSearch && matchesType && matchesCategory;
    });

    return list.sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'name') {
        comparison = a.name.localeCompare(b.name, 'es', { sensitivity: 'base' });
      } else if (sortBy === 'description') {
        const descA = a.description || '';
        const descB = b.description || '';
        comparison = descA.localeCompare(descB, 'es', { sensitivity: 'base' });
      } else if (sortBy === 'category') {
        const catA = a.category || '';
        const catB = b.category || '';
        comparison = catA.localeCompare(catB, 'es', { sensitivity: 'base' });
        // Secondary sort by name
        if (comparison === 0) {
          comparison = a.name.localeCompare(b.name, 'es', { sensitivity: 'base' });
        }
      } else if (sortBy === 'price') {
        comparison = (a.price || 0) - (b.price || 0);
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [products, searchTerm, typeFilter, selectedCategory, sortBy, sortOrder]);

  const handleHeaderSort = (field: 'name' | 'description' | 'category' | 'price') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Inventario y Productos</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Control de stock en tiempo real, catálogo de productos ordenado, precios, márgenes y categorías.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
          {/* Botón Catálogo PDF para Clientes (Proyectos y Ferretería) */}
          <button
            onClick={() => setIsCatalogModalOpen(true)}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 active:bg-amber-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer border border-amber-600"
            title="Generar catálogo en formato PDF con diseño para proyectos y ferreterías de Panamá (Cel: 64429775)"
          >
            <FileText className="w-4 h-4 text-white" />
            <span>Catálogo PDF Clientes</span>
          </button>

          <button
            onClick={onOpenNewProduct}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>Agregar Producto / Servicio</span>
          </button>
        </div>
      </div>

      {/* Visualización con Recharts: Top 5 Productos con Mayor Rotación de Ventas (Último Mes) */}
      <InventoryTurnoverChart
        products={products}
        invoices={invoices}
        onSelectProduct={(product) => setSelectedDetailProduct(product)}
      />

      {/* Filter and Sort Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Type Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setTypeFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              typeFilter === 'all'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Todos ({products.length})
          </button>

          <button
            onClick={() => setTypeFilter('product')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              typeFilter === 'product'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-100'
            }`}
          >
            Productos Físicos ({products.filter(p => p.type === 'product').length})
          </button>

          <button
            onClick={() => setTypeFilter('service')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              typeFilter === 'service'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-100'
            }`}
          >
            Servicios ({products.filter(p => p.type === 'service').length})
          </button>
        </div>

        {/* Ordering & Category Controls */}
        <div className="flex flex-wrap items-center gap-2.5 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
          
          {/* Category Filter */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-semibold text-slate-500">Categoría:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-transparent font-bold text-slate-800 outline-hidden cursor-pointer"
            >
              <option value="all">Todas ({categories.length})</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Sort By Selector */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200 text-xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-semibold text-slate-500">Ordenar por:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent font-bold text-slate-800 outline-hidden cursor-pointer"
            >
              <option value="name">Nombre</option>
              <option value="description">Descripción</option>
              <option value="category">Categoría</option>
              <option value="price">Precio de Venta</option>
            </select>
          </div>

          {/* Sort Order Toggle */}
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors border border-slate-200"
            title={sortOrder === 'asc' ? 'Orden Ascendente (Click para Descendente)' : 'Orden Descendente (Click para Ascendente)'}
          >
            {sortBy === 'price' ? (
              sortOrder === 'asc' ? <ArrowUp10 className="w-4 h-4 text-emerald-600" /> : <ArrowDown10 className="w-4 h-4 text-emerald-600" />
            ) : (
              sortOrder === 'asc' ? <ArrowUpAZ className="w-4 h-4 text-sky-600" /> : <ArrowDownZA className="w-4 h-4 text-sky-600" />
            )}
            <span className="text-[11px] font-bold">{sortOrder === 'asc' ? 'Asc' : 'Desc'}</span>
          </button>

        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm text-slate-600 border-collapse">
            <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200 select-none">
              <tr>
                <th className="py-3 px-4">SKU / Código</th>
                
                <th 
                  onClick={() => handleHeaderSort('name')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/70 transition-colors"
                  title="Ordenar por Nombre"
                >
                  <div className="flex items-center gap-1">
                    <span>Nombre</span>
                    {sortBy === 'name' && (
                      <span className="text-sky-600 font-extrabold">{sortOrder === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </div>
                </th>

                <th 
                  onClick={() => handleHeaderSort('description')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/70 transition-colors"
                  title="Ordenar por Descripción"
                >
                  <div className="flex items-center gap-1">
                    <span>Descripción</span>
                    {sortBy === 'description' && (
                      <span className="text-sky-600 font-extrabold">{sortOrder === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </div>
                </th>

                <th 
                  onClick={() => handleHeaderSort('category')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/70 transition-colors"
                  title="Ordenar por Categoría"
                >
                  <div className="flex items-center gap-1">
                    <span>Categoría</span>
                    {sortBy === 'category' && (
                      <span className="text-sky-600 font-extrabold">{sortOrder === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </div>
                </th>

                <th className="py-3 px-4 text-right">Costo ($)</th>

                <th 
                  onClick={() => handleHeaderSort('price')}
                  className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100/70 transition-colors"
                  title="Ordenar por Precio de Venta"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Precio Venta ($)</span>
                    {sortBy === 'price' && (
                      <span className="text-sky-600 font-extrabold">{sortOrder === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </div>
                </th>

                <th className="py-3 px-4 text-right">Margen %</th>
                <th className="py-3 px-4 text-center">Stock Actual</th>
                <th className="py-3 px-4 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {sortedAndFilteredProducts.map((p) => {
                const marginPercent = p.price > 0 ? (((p.price - p.cost) / p.price) * 100) : 0;
                const minStockLimit = p.minStockAlert ?? (p.min_stock ?? 0);
                const isLowStock = p.type === 'product' && p.stock <= minStockLimit;
                const prodImg = p.imageUrl || p.image_url;

                return (
                  <tr key={p.id} className={`hover:bg-slate-50/50 transition-colors border-b border-slate-50 ${isLowStock ? 'bg-rose-50/30' : ''}`}>
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">{p.sku}</td>
                    
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        {prodImg ? (
                          <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 shadow-2xs shrink-0 overflow-hidden flex items-center justify-center p-0.5">
                            <img
                              src={prodImg}
                              alt={p.name}
                              className="w-full h-full object-contain"
                              onError={(e) => {
                                (e.target as HTMLElement).style.display = 'none';
                              }}
                            />
                          </div>
                        ) : (
                          <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0 text-slate-400">
                            <Package className="w-5 h-5 text-slate-400" />
                          </div>
                        )}
                        <div>
                          <div className="font-bold text-slate-900">{p.name}</div>
                          {p.material && (
                            <span className="inline-block mt-0.5 px-1.5 py-0.2 bg-amber-50 text-amber-800 rounded text-[10px] font-bold border border-amber-200">
                              Mat: {p.material}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-xs text-slate-500 max-w-xs truncate" title={p.description || 'Sin descripción'}>
                        {p.description || <span className="text-slate-300 italic">Sin descripción</span>}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-slate-500 font-medium">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-semibold border border-slate-200">
                        {p.category}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono text-slate-500">${p.cost.toFixed(2)}</td>
                    
                    <td className="py-3.5 px-4 text-right font-mono font-extrabold text-slate-900">
                      ${p.price.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-600">
                      {marginPercent.toFixed(0)}%
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      {p.type === 'product' ? (
                        <div className="flex items-center justify-center gap-1.5">
                          <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                            isLowStock 
                              ? 'bg-rose-100 text-rose-700 font-bold' 
                              : 'bg-emerald-100 text-emerald-700 font-bold'
                          }`}>
                            {p.stock} {p.unit}
                          </span>
                          {isLowStock && <AlertTriangle className="w-3.5 h-3.5 text-rose-600" title={`Alerta de stock bajo (Mínimo: ${minStockLimit})`} />}
                        </div>
                      ) : (
                        <span className="text-[11px] font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                          Servicio (Ilimitado)
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Eye Button: View Single Product & Modify */}
                        <button
                          onClick={() => setSelectedDetailProduct(p)}
                          className="p-1.5 text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-lg transition-colors border border-sky-100 flex items-center gap-1 font-semibold text-xs"
                          title="Ver artículo solo y modificar"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span className="hidden xl:inline">Ver Ficha</span>
                        </button>

                        {/* Pencil Button: Edit Product Form */}
                        <button
                          onClick={() => setSelectedEditProduct(p)}
                          className="p-1.5 text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors border border-amber-100 flex items-center gap-1 font-semibold text-xs"
                          title="Editar producto"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                          <span className="hidden xl:inline">Editar</span>
                        </button>

                        {/* Stock Adjustment Button */}
                        {p.type === 'product' && (
                          <button
                            onClick={() => onOpenStockAdjust(p)}
                            className="px-2 py-1 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1"
                            title="Ajustar Stock"
                          >
                            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
                            <span className="hidden xl:inline">Stock</span>
                          </button>
                        )}

                        {/* Delete Button */}
                        <button
                          onClick={() => handleDeleteProduct(p)}
                          className="p-1.5 text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors border border-rose-100 flex items-center gap-1 font-semibold text-xs"
                          title="Eliminar artículo"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                          <span className="hidden xl:inline">Eliminar</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {sortedAndFilteredProducts.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                    No hay productos registrados que coincidan con los filtros seleccionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Detail / Single Article View Modal */}
      <ProductDetailModal
        product={selectedDetailProduct}
        onClose={() => setSelectedDetailProduct(null)}
      />

      {/* Product Edit Modal */}
      <ProductFormModal
        isOpen={!!selectedEditProduct}
        productToEdit={selectedEditProduct}
        onClose={() => setSelectedEditProduct(null)}
      />

      {/* Catalog Export Modal */}
      <CatalogExportModal
        isOpen={isCatalogModalOpen}
        onClose={() => setIsCatalogModalOpen(false)}
        products={products}
        companyProfile={companyProfile}
      />

    </div>
  );
};
